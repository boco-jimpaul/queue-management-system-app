package com.example.bortour_rider;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.List;

public class RideHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_history);

        // Initialize Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Remove the app name/title from the Toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(""); // Remove the title
        }

        // Initialize ListView and Adapter
        ListView rideHistoryList = findViewById(R.id.rideHistoryList);
        List<RideHistoryItem> rideHistoryItems = new ArrayList<>();
        rideHistoryItems.add(new RideHistoryItem("Playa De Boro Beach", "4 Days ago", "Maypangdan", "6.8 km", "2 Passengers", "₱30.00"));
        rideHistoryItems.add(new RideHistoryItem("Playa De Boro Beach", "4 Days ago", "Maypangdan", "6.8 km", "2 Passengers", "₱30.00"));
        rideHistoryItems.add(new RideHistoryItem("Ganap Cave", "4 Days ago", "Maypangdan", "8 km", "2 Passengers", "₱30.00"));
        rideHistoryItems.add(new RideHistoryItem("Hilangagan Beach", "2 Days ago", "Maypangdan", "6.8 km", "2 Passengers", "₱30.00"));

        // Add more items here

        RideHistoryAdapter adapter = new RideHistoryAdapter(this, rideHistoryItems);
        rideHistoryList.setAdapter(adapter);

        // Handle back button press
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish(); // Close the activity
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Handle the back button action
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
