package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MessageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_message, container, false);

        RecyclerView recyclerView = rootView.findViewById(R.id.recycler_view_messages);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        List<RecentMessageItem> messageList = new ArrayList<>();
        // Populate messageList with your data (dummy data for example)
        messageList.add(new RecentMessageItem(1, R.drawable.profile, "Jim kwik", "where are you?", "10:00am"));
        messageList.add(new RecentMessageItem(2, R.drawable.profile, "Nino Mulac", "where are you?", "11:00am"));
        messageList.add(new RecentMessageItem(3, R.drawable.profile, "Joel de Caprio", "where are you?", "12:00pm"));
        messageList.add(new RecentMessageItem(3, R.drawable.profile, "Luis Mansano", "where are you?", "12:40pm"));

        // Initialize adapter with click listener
        RecentMessagesAdapter adapter = new RecentMessagesAdapter(getActivity(), messageList, position -> {
            // Handle item click here, e.g., navigate to message details screen
            RecentMessageItem item = messageList.get(position);
            openMessageDetails(item);
        });

        recyclerView.setAdapter(adapter);

        return rootView;
    }

    private void openMessageDetails(RecentMessageItem item) {
        // Example: Navigate to message details screen
        Intent intent = new Intent(getActivity(), MessageDetailsActivity.class);
        intent.putExtra("username", item.getUsername());
        startActivity(intent);
    }
}

