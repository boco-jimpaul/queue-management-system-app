package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.bortour_rider.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private String name, email, contact;
    private int userId;

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Get user details from the Intent
        if (savedInstanceState == null) {
            Intent intent = getIntent();
            userId = intent.getIntExtra("id", -1);
            name = intent.getStringExtra("name");
            email = intent.getStringExtra("email");
            contact = intent.getStringExtra("contact");
        } else {
            userId = savedInstanceState.getInt("userId");
            name = savedInstanceState.getString("name");
            email = savedInstanceState.getString("email");
            contact = savedInstanceState.getString("contact");
        }

        // Replace with the initial fragment
        replaceFragment(new HomeFragment());

        binding.bottomNavv.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.home) {
                replaceFragment(new HomeFragment());
            } else if (itemId == R.id.message) {
                replaceFragment(new MessageFragment());
            } else if (itemId == R.id.profile) {
                replaceFragment(ProfileFragment.newInstance(userId, name, email, contact));
            }

            return true;
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("userId", userId);
        outState.putString("name", name);
        outState.putString("email", email);
        outState.putString("contact", contact);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        userId = savedInstanceState.getInt("userId");
        name = savedInstanceState.getString("name");
        email = savedInstanceState.getString("email");
        contact = savedInstanceState.getString("contact");
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.commit();
    }
}