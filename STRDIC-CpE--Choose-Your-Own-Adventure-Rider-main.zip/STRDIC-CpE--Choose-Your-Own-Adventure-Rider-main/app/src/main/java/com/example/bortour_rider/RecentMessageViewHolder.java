package com.example.bortour_rider;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecentMessageViewHolder extends RecyclerView.ViewHolder {
    private ImageView profilePic;
    private TextView username;
    private TextView lastMessage;
    private TextView time;

    public RecentMessageViewHolder(@NonNull View itemView) {
        super(itemView);
        profilePic = itemView.findViewById(R.id.profile_pic);
        username = itemView.findViewById(R.id.username);
        lastMessage = itemView.findViewById(R.id.last_message);
        time = itemView.findViewById(R.id.time);
    }

    public void bind(RecentMessageItem item) {
        profilePic.setImageResource(item.getProfilePic());
        username.setText(item.getUsername());
        lastMessage.setText(item.getLastMessage());
        time.setText(item.getTime());
    }
}

