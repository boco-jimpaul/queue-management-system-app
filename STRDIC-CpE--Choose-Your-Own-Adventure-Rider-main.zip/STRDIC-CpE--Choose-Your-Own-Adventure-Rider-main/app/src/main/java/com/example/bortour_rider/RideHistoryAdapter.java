package com.example.bortour_rider;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.List;

public class RideHistoryAdapter extends ArrayAdapter<RideHistoryItem> {
    private final Context context;
    private final List<RideHistoryItem> rideHistoryItems;

    public RideHistoryAdapter(@NonNull Context context, @NonNull List<RideHistoryItem> rideHistoryItems) {
        super(context, 0, rideHistoryItems);
        this.context = context;
        this.rideHistoryItems = rideHistoryItems;
    }

    @Override
    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_ride_history, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tvDestination = convertView.findViewById(R.id.tvDestination);
            viewHolder.tvTimeAgo = convertView.findViewById(R.id.tvTimeAgo);
            viewHolder.tvLocation = convertView.findViewById(R.id.tvLocation);
            viewHolder.tvDistance = convertView.findViewById(R.id.tvDistance);
            viewHolder.tvPassengers = convertView.findViewById(R.id.tvPassengers);
            viewHolder.tvFare = convertView.findViewById(R.id.tvFare);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        RideHistoryItem currentItem = rideHistoryItems.get(position);

        viewHolder.tvDestination.setText(currentItem.destination);
        viewHolder.tvTimeAgo.setText(currentItem.timeAgo);
        viewHolder.tvLocation.setText(currentItem.location);
        viewHolder.tvDistance.setText(currentItem.distance);
        viewHolder.tvPassengers.setText(currentItem.passengers);
        viewHolder.tvFare.setText(currentItem.fare);

        return convertView;
    }

    static class ViewHolder {
        TextView tvDestination;
        TextView tvTimeAgo;
        TextView tvLocation;
        TextView tvDistance;
        TextView tvPassengers;
        TextView tvFare;
    }
}
