package com.example.bortour_rider;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecentMessagesAdapter extends RecyclerView.Adapter<RecentMessageViewHolder> {

    private Context context;
    private List<RecentMessageItem> messageList;
    private OnItemClickListener listener;

    public RecentMessagesAdapter(Context context, List<RecentMessageItem> messageList, OnItemClickListener listener) {
        this.context = context;
        this.messageList = messageList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecentMessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recent_message_row, parent, false);
        return new RecentMessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentMessageViewHolder holder, int position) {
        RecentMessageItem item = messageList.get(position);
        holder.bind(item);  // Update the bind method to pass item only
        holder.itemView.setOnClickListener(v -> listener.onItemClick(position));
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
