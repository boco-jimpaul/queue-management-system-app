package com.example.bortour_rider;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private TextView nameTextView, emailTextView;
    private static final String TAG = "ProfileFragment";
    private static final String ARG_ID = "id";
    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";

    private String name, email, contact;
    private int userId;

    public ProfileFragment() {
        // Required empty public constructor
    }

    public static ProfileFragment newInstance(int id, String name, String email, String contact) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_ID, id);
        args.putString(ARG_NAME, name);
        args.putString(ARG_EMAIL, email);
        args.putString(ARG_CONTACT, contact);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            userId = getArguments().getInt(ARG_ID, -1);
            name = getArguments().getString(ARG_NAME);
            email = getArguments().getString(ARG_EMAIL);
            contact = getArguments().getString(ARG_CONTACT);
        } else {
            Log.e(TAG, "Arguments are null");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.profile, container, false);

        nameTextView = rootView.findViewById(R.id.nametextView);
        emailTextView = rootView.findViewById(R.id.emailtextView);

        // Set TextView content
        if (name != null) {
            nameTextView.setText(name);
        }
        if (email != null) {
            emailTextView.setText(email);
        }

        // Set up buttons
        setupButtons(rootView);

        return rootView;
    }

    private void setupButtons(View rootView) {
        View logoutButton = rootView.findViewById(R.id.br5);
        if (logoutButton != null) {
            logoutButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onLogoutClick(v);
                }
            });
        } else {
            Log.e(TAG, "Logout button not found in the layout.");
        }

        View editProfileButton = rootView.findViewById(R.id.br1);
        if (editProfileButton != null) {
            editProfileButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onEdit(v);
                }
            });
        } else {
            Log.e(TAG, "Edit Profile button not found in the layout.");
        }

        View earningsButton = rootView.findViewById(R.id.br2);
        if (earningsButton != null) {
            earningsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onEarningsClick(v);
                }
            });
        } else {
            Log.e(TAG, "Earnings button not found in the layout.");
        }

        ImageButton arrowButton = rootView.findViewById(R.id.arrowButton);
        if (arrowButton != null) {
            arrowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle arrow button click (navigate back or perform desired action)
                    requireActivity().onBackPressed(); // Go back to previous fragment/activity
                }
            });
        } else {
            Log.e(TAG, "Arrow button not found in the layout.");
        }

        // Find the ride history button by its ID and set an onClickListener
        View rideHistoryButton = rootView.findViewById(R.id.br3);
        if (rideHistoryButton != null) {
            Log.d(TAG, "Ride History button found.");
            rideHistoryButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "Ride History button clicked.");
                    onRideHistoryClick(v);
                }
            });
        } else {
            Log.e(TAG, "Ride History button not found in the layout.");
        }

        // Find the feedback and ratings button by its ID and set an onClickListener
        View feedbackButton = rootView.findViewById(R.id.br4);
        if (feedbackButton != null) {
            feedbackButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onFeedbackClick(v);
                }
            });
        } else {
            Log.e(TAG, "Feedback button not found in the layout.");
        }

      
    }

    public void onLogoutClick(View view) {
        try {
            showLogoutDialog();
        } catch (Exception e) {
            Log.e(TAG, "Error in onLogoutClick: " + e.getMessage());
        }
    }

    private void showLogoutDialog() {
        try {
            final Dialog dialog = new Dialog(requireActivity());
            dialog.setContentView(R.layout.logout_popup);

            Button btnCancel = dialog.findViewById(R.id.btnLogoutCancel);
            Button btnConfirm = dialog.findViewById(R.id.btnLogoutConfirm);

            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            btnConfirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    logoutUser();
                    dialog.dismiss();
                }
            });

            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error in showLogoutDialog: " + e.getMessage());
        }
    }

    private void logoutUser() {
        try {
            Intent intent = new Intent(requireActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            requireActivity().finish();
        } catch (Exception e) {
            Log.e(TAG, "Error in logoutUser: " + e.getMessage());
        }
    }

    public void onEdit(View view) {
        try {
            Intent editIntent = new Intent(getActivity(), EditProfile.class);
            editIntent.putExtra("id", userId);
            editIntent.putExtra("name", name);
            editIntent.putExtra("email", email);
            editIntent.putExtra("contact", contact);
            startActivity(editIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error in onEdit: " + e.getMessage());
        }
    }

    public void onEarningsClick(View view) {
        try {
            Intent intent = new Intent(requireActivity(), MyEarningsActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error in onEarningsClick: " + e.getMessage());
        }
    }

    // Method to handle Ride History button click
    public void onRideHistoryClick(View view) {
        try {
            Intent intent = new Intent(requireActivity(), RideHistoryActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error in onRideHistoryClick: " + e.getMessage());
        }
    }

    // Method to handle Feedback and Ratings button click
    public void onFeedbackClick(View view) {
        try {
            Intent intent = new Intent(requireActivity(), ReviewActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error in onFeedbackClick: " + e.getMessage());
        }
    }
}
