package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class ProfileActivity extends AppCompatActivity {

    private String name, email, contact;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_profile);

        Intent intent = getIntent();
        userId = intent.getIntExtra("id", -1);
        name = intent.getStringExtra("name");
        email = intent.getStringExtra("email");
        contact = intent.getStringExtra("contact");

        ProfileFragment profileFragment = ProfileFragment.newInstance(userId, name, email, contact);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, profileFragment); // Replace with your fragment container ID
        fragmentTransaction.commit();
    }
}