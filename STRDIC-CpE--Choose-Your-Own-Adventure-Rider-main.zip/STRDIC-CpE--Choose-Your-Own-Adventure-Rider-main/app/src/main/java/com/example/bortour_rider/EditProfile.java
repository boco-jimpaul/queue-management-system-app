package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class EditProfile extends AppCompatActivity {

    private Retrofit retrofit;
    private RetrofitInterface retrofitInterface;
    private static final String BASE_URL = "http://192.168.11.199:3000";

    private EditText name, email, contact;
    private Button updateButton, cancelButton;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        ImageButton arrowButton = findViewById(R.id.arrowButton);
        arrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        retrofitInterface = retrofit.create(RetrofitInterface.class);

        name = findViewById(R.id.nameEdit);
        email = findViewById(R.id.emailEdit);
        contact = findViewById(R.id.contactEdit);
        updateButton = findViewById(R.id.updateButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Get user details from the Intent
        Intent intent = getIntent();
        userId = intent.getIntExtra("id", -1);
        name.setText(intent.getStringExtra("name"));
        email.setText(intent.getStringExtra("email"));
        contact.setText(intent.getStringExtra("contact"));

        handleUpdate();
        handleCancel();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void handleUpdate() {
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(name.getText().toString())) {
                    name.setError("Username is required");
                    return;
                }
                if (TextUtils.isEmpty(email.getText().toString())) {
                    email.setError("Email is required");
                    return;
                }
                if (TextUtils.isEmpty(contact.getText().toString())) {
                    contact.setError("Contact number is required");
                    return;
                }

                HashMap<String, String> map = new HashMap<>();
                map.put("id", String.valueOf(userId));
                map.put("name", name.getText().toString());
                map.put("email", email.getText().toString());
                map.put("contact", contact.getText().toString());

                Call<User> call = retrofitInterface.updateUser(map);

                call.enqueue(new Callback<User>() {
                    @Override
                    public void onResponse(Call<User> call, Response<User> response) {
                        if (response.code() == 200) {
                            User updatedUser = response.body();
                            Toast.makeText(EditProfile.this, "Profile updated successfully", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(EditProfile.this, MainActivity.class);
                            intent.putExtra("id", userId);
                            intent.putExtra("name", updatedUser.getName());
                            intent.putExtra("email", updatedUser.getEmail());
                            intent.putExtra("contact", updatedUser.getContact());
                            startActivity(intent);
                            finish();
                        } else if (response.code() == 404) {
                            Toast.makeText(EditProfile.this, "User not found", Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<User> call, Throwable t) {
                        Toast.makeText(EditProfile.this, t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }
    private void handleCancel() {
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EditProfile.this, ProfileActivity.class);
                intent.putExtra("id", userId);
                intent.putExtra("name", name.getText().toString());
                intent.putExtra("email", email.getText().toString());
                intent.putExtra("contact", contact.getText().toString());
                startActivity(intent);
                finish();
            }
        });
    }
}
