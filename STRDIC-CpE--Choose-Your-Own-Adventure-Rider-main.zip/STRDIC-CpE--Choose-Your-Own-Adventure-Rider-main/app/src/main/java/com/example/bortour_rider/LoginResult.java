package com.example.bortour_rider;

public class LoginResult {

    private int id;
    private String name;
    private String email;
    private String contact;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getContact() {
        return contact; // Add this getter
    }
}