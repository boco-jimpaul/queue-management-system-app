package com.example.bortour_rider;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_feedback);

        // Initialize Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(""); // Set title
        }

        // Initialize ListView and Adapter
        ListView reviewListView = findViewById(R.id.ratingFeedbackList);
        List<ReviewItem> reviewItems = new ArrayList<>();
        reviewItems.add(new ReviewItem("Alice", 4.5f, "2 days ago", "Great service!"));
        reviewItems.add(new ReviewItem("Bob", 3.0f, "1 week ago", "It was okay."));
        // Add more items here

        ReviewAdapter adapter = new ReviewAdapter(this, reviewItems);
        reviewListView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Handle the back button action
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
