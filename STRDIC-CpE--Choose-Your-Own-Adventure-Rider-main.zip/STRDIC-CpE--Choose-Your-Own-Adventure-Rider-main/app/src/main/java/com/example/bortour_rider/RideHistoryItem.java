package com.example.bortour_rider;

public class RideHistoryItem {
    public String destination;
    public String timeAgo;
    public String location;
    public String distance;
    public String passengers;
    public String fare;

    public RideHistoryItem(String destination, String timeAgo, String location, String distance, String passengers, String fare) {
        this.destination = destination;
        this.timeAgo = timeAgo;
        this.location = location;
        this.distance = distance;
        this.passengers = passengers;
        this.fare = fare;
    }
}
