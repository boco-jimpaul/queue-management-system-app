package com.example.bortour_rider;

public class Message {
    private String text;
    private boolean isSentByCurrentUser; // Indicates if the message is sent by the current user
    private String sender; // Username of the sender

    // Constructor
    public Message(String text, boolean isSentByCurrentUser, String sender) {
        this.text = text;
        this.isSentByCurrentUser = isSentByCurrentUser;
        this.sender = sender;
    }

    // Getters
    public String getText() {
        return text;
    }

    public boolean isSentByCurrentUser() {
        return isSentByCurrentUser;
    }

    public String getSender() {
        return sender;
    }
}
