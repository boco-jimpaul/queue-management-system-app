package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MessageDetailsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MessageAdapter messageAdapter;
    private List<Message> messages;
    private String username;
    private EditText messageInput;
    private ImageButton sendButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message_details_layout);

        // Toolbar setup
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Ensure support action bar is not null before setting up back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish(); // Navigate back when back button is clicked
                }
            });

            // Set the title to an empty string (or any desired title)
            getSupportActionBar().setTitle(""); // Set empty string to remove title
        }

        // Set username from intent extras
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("username")) {
            username = intent.getStringExtra("username");
            TextView usernameTextView = findViewById(R.id.username);
            usernameTextView.setText(username);
        }

        // RecyclerView setup
        recyclerView = findViewById(R.id.recycler_view_messages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize your messages (for example, from a database or API)
        messages = new ArrayList<>();
        // Example messages
        messages.add(new Message("where are you now?", false, username));

        // Add more messages as needed


        messageAdapter = new MessageAdapter(messages, username);
        recyclerView.setAdapter(messageAdapter);

        // Input and send button setup
        messageInput = findViewById(R.id.message_input);
        sendButton = findViewById(R.id.send_btn);

        // Send button click listener
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    private void sendMessage() {
        String messageText = messageInput.getText().toString().trim();
        if (!messageText.isEmpty()) {
            Message newMessage = new Message(messageText, true, username);
            messages.add(newMessage);
            messageAdapter.notifyItemInserted(messages.size() - 1);
            recyclerView.scrollToPosition(messages.size() - 1);
            messageInput.setText(""); // Clear the input field
        }
    }
}
