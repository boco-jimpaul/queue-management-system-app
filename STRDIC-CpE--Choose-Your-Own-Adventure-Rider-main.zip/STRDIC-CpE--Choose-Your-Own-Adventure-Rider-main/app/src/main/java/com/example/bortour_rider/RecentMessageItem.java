package com.example.bortour_rider;

public class RecentMessageItem {
    private final int id; // Unique identifier for the message item
    private final int profilePic; // Resource ID of profile picture
    private final String username;
    private final String lastMessage;
    private final String time;

    public RecentMessageItem(int id, int profilePic, String username, String lastMessage, String time) {
        this.id = id;
        this.profilePic = profilePic;
        this.username = username;
        this.lastMessage = lastMessage;
        this.time = time;
    }

    // Getters for all fields (no setters as fields are final)
    public int getId() {
        return id;
    }

    public int getProfilePic() {
        return profilePic;
    }

    public String getUsername() {
        return username;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public String getTime() {
        return time;
    }
}
