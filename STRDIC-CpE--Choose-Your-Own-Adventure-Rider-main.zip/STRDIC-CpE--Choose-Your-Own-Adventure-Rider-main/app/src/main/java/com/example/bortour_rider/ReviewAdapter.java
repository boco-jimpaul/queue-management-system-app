package com.example.bortour_rider;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

public class ReviewAdapter extends BaseAdapter {
    private Context context;
    private List<ReviewItem> reviewItems;

    public ReviewAdapter(Context context, List<ReviewItem> reviewItems) {
        this.context = context;
        this.reviewItems = reviewItems;
    }

    @Override
    public int getCount() {
        return reviewItems.size();
    }

    @Override
    public Object getItem(int position) {
        return reviewItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.rating_feedback_item, parent, false);
        }

        ReviewItem reviewItem = reviewItems.get(position);

        TextView reviewerName = convertView.findViewById(R.id.reviewer_name);
        RatingBar reviewRating = convertView.findViewById(R.id.review_rating);
        TextView reviewDate = convertView.findViewById(R.id.review_date);
        TextView reviewText = convertView.findViewById(R.id.review_text);

        reviewerName.setText(reviewItem.getReviewerName());
        reviewRating.setRating(reviewItem.getRating());
        reviewDate.setText(reviewItem.getReviewDate());
        reviewText.setText(reviewItem.getReviewText());

        return convertView;
    }
}
