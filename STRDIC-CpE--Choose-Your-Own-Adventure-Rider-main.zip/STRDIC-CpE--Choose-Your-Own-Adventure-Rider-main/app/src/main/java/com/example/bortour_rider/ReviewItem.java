package com.example.bortour_rider;

public class ReviewItem {
    private String reviewerName;
    private float rating;
    private String reviewDate;
    private String reviewText;

    public ReviewItem(String reviewerName, float rating, String reviewDate, String reviewText) {
        this.reviewerName = reviewerName;
        this.rating = rating;
        this.reviewDate = reviewDate;
        this.reviewText = reviewText;
    }

    public String getReviewerName() {
        return reviewerName;
    }

    public float getRating() {
        return rating;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public String getReviewText() {
        return reviewText;
    }
}
