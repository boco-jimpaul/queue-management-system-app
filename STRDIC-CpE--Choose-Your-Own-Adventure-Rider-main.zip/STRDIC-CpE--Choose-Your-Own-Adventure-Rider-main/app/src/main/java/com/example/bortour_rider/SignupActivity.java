package com.example.bortour_rider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignupActivity extends AppCompatActivity {

    private Retrofit retrofit;
    private RetrofitInterface retrofitInterface;
    private String BASE_URL = "http://192.168.11.199:3000";

    private EditText name, email, contact, password, driversId;
    private Button signupBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        retrofitInterface = retrofit.create(RetrofitInterface.class);

        name = findViewById(R.id.nameEdit);
        email = findViewById(R.id.emailEdit);
        contact = findViewById(R.id.contactEdit);
        password = findViewById(R.id.passwordEdit);
        driversId = findViewById(R.id.driversIdEdit);
        signupBtn = findViewById(R.id.signup);

        handleSignup();
    }

    private void handleSignup() {
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(name.getText().toString())) {
                    name.setError("Username is required");
                    return;
                }
                if (TextUtils.isEmpty(email.getText().toString())) {
                    email.setError("Email is required");
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                    email.setError("Enter a valid email");
                    return;
                }
                if (TextUtils.isEmpty(contact.getText().toString())) {
                    contact.setError("Contact number is required");
                    return;
                }
                if (TextUtils.isEmpty(password.getText().toString())) {
                    password.setError("Password is required");
                    return;
                }
                if (TextUtils.isEmpty(driversId.getText().toString())) {
                    driversId.setError("Driver's ID is required");
                    return;
                }
                if (!isValidDriversId(driversId.getText().toString())) {
                    driversId.setError("Invalid Driver's ID format");
                    return;
                }

                HashMap<String, String> map = new HashMap<>();
                map.put("name", name.getText().toString());
                map.put("email", email.getText().toString());
                map.put("contact", contact.getText().toString());
                map.put("password", password.getText().toString());
                map.put("driversId", driversId.getText().toString());

                Call<Void> call = retrofitInterface.executeSignup(map);

                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.code() == 200) {
                            Toast.makeText(SignupActivity.this, "Signed up successfully", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        } else if (response.code() == 400) {
                            Toast.makeText(SignupActivity.this, "Already registered", Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(SignupActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        TextView loginText = findViewById(R.id.loginText);
        loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidDriversId(String driversId) {
        String regex = "^[A-Z]\\d{2}-\\d{3}-\\d{6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(driversId);
        return matcher.matches();
    }
}