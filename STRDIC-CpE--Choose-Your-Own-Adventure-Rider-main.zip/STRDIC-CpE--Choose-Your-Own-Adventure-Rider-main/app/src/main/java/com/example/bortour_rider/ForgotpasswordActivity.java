package com.example.bortour_rider;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ForgotpasswordActivity extends AppCompatActivity {

    EditText email;
    Button forgotpasswordBtn;
    TextView loginText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);

        email = findViewById(R.id.emailEdit);
        forgotpasswordBtn = findViewById(R.id.forgotpasswordButton);
        loginText = findViewById(R.id.loginText);

        forgotpasswordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(email.getText().toString())) {
                    email.setError("Email is required");
                    return;
                }

                Toast.makeText(ForgotpasswordActivity.this, "Reset Password Successfully", Toast.LENGTH_LONG).show();
            }
        });

        loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ForgotpasswordActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}